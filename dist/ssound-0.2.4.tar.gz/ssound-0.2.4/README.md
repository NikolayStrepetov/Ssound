# Ssound

A library for audio processing

## Installation

To install the library use:
pip install git+https://github.com/NikolayStrepetov/Ssound.git

It is also requires NumPy, SciPy and Matplotlib for start
